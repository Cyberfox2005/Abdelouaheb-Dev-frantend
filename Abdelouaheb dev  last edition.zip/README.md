
  # Abdelouaheb dev (Community)

  This is a code bundle for Abdelouaheb dev (Community). The original project is available at https://www.figma.com/design/aoFblw1yAqy63tDXZZhTC9/Abdelouaheb-dev--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  