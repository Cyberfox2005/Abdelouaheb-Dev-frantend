import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Skills } from "./components/Skills";
import { Projects } from "./components/Projects";
import { Experience } from "./components/Experience";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { ThemeProvider } from "./components/ThemeProvider";
import { ThemeToggle } from "./components/ThemeToggle";
import { LanguageProvider } from "./components/LanguageProvider";
import { LanguageToggle } from "./components/LanguageToggle";

export default function App() {
  return (
    <LanguageProvider>
      <ThemeProvider defaultTheme="dark">
        <div className="min-h-screen">
          <div className="fixed top-4 right-4 z-50 flex gap-3">
            <LanguageToggle />
            <ThemeToggle />
          </div>
          <Hero />
          <About />
          <Skills />
          <Projects />
          <Experience />
          <Contact />
          <Footer />
        </div>
      </ThemeProvider>
    </LanguageProvider>
  );
}
