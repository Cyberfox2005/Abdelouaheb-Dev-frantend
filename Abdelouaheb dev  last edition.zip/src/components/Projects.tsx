import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ExternalLink, Github } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { useLanguage } from "./LanguageProvider";

const projects = [
  {
    title: "Supermarket Management System",
    description: "Comprehensive POS and inventory management system for supermarkets with sales tracking, stock management, and customer analytics.",
    image: "https://images.unsplash.com/photo-1628102491629-778571d893a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXBlcm1hcmtldCUyMHNob3BwaW5nfGVufDF8fHx8MTc2MTMzNzU1Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    tags: ["PHP", "Laravel", "MySQL", "Bootstrap"],
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    title: "Hospital Management System",
    description: "Complete hospital management solution with patient records, appointment scheduling, billing, and staff management.",
    image: "https://images.unsplash.com/photo-1564732005956-20420ebdab60?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMGhlYWx0aGNhcmV8ZW58MXx8fHwxNzYxMzE5MjM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    tags: ["Django", "Python", "PostgreSQL", "React"],
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    title: "E-Commerce Platform",
    description: "A full-stack e-commerce solution with payment integration, inventory management, and real-time analytics.",
    image: "https://images.unsplash.com/photo-1658297063569-162817482fb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY29tbWVyY2UlMjB3ZWJzaXRlfGVufDF8fHx8MTc2MTM5MjI2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    tags: ["React", "Node.js", "SQL", "Tailwind"],
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    title: "Food Delivery Mobile App",
    description: "Cross-platform food delivery application with real-time order tracking, payment gateway, and restaurant management.",
    image: "https://images.unsplash.com/photo-1644946763226-22c60fcb6635?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwZm9vZCUyMGRlbGl2ZXJ5fGVufDF8fHx8MTc2MTM4NTE5N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    tags: ["React Native", "Node.js", "MongoDB", "Dart"],
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    title: "Social Media Platform",
    description: "Feature-rich social networking platform with posts, messaging, notifications, and user profiles.",
    image: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NpYWwlMjBtZWRpYSUyMGFwcHxlbnwxfHx8fDE3NjEzNTU2MzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    tags: ["React", "Laravel", "MySQL", "Bootstrap"],
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    title: "Real Estate Listing App",
    description: "Property listing and management platform with advanced search, virtual tours, and agent dashboard.",
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWFsJTIwZXN0YXRlJTIwcHJvcGVydHl8ZW58MXx8fHwxNzYxMzcxMTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    tags: ["PHP", "JavaScript", "SQL", "HTML/CSS"],
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    title: "Online Learning Platform",
    description: "E-learning platform with video courses, quizzes, progress tracking, and certification system.",
    image: "https://images.unsplash.com/photo-1669607960578-f7d7fd363e5e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBsZWFybmluZyUyMG9ubGluZXxlbnwxfHx8fDE3NjEzMzMxNjh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    tags: ["Django", "React", "PostgreSQL", "Python"],
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    title: "Fitness Tracking Mobile App",
    description: "Cross-platform mobile application for tracking workouts, nutrition, and personal fitness goals.",
    image: "https://images.unsplash.com/photo-1609921212029-bb5a28e60960?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBkZXNpZ258ZW58MXx8fHwxNzYxMzE4MDQ5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    tags: ["Flutter", "Dart", "Swift", "SQL"],
    liveUrl: "#",
    githubUrl: "#"
  }
];

export function Projects() {
  const { t } = useLanguage();
  
  return (
    <section id="projects" className="py-24 bg-gradient-to-b from-white to-gray-50 dark:from-brand-dark dark:to-brand-darker">
      <div className="container mx-auto px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="mb-4 bg-gradient-to-r from-brand-cyan to-brand-purple bg-clip-text text-transparent">{t('projectsTitle')}</h2>
            <div className="w-20 h-1 bg-gradient-to-r from-brand-cyan via-brand-green to-brand-purple mx-auto mb-6"></div>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              {t('projectsDescription')}
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all hover:-translate-y-2 border border-brand-cyan/10 dark:border-brand-cyan/20">
                <div className="relative h-48 overflow-hidden group">
                  <ImageWithFallback
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-dark/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                
                <div className="p-6">
                  <h3 className="mb-3 bg-gradient-to-r from-brand-cyan to-brand-purple bg-clip-text text-transparent">{project.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.tags.map((tag, tagIndex) => (
                      <Badge key={tagIndex} className="bg-brand-cyan/10 text-brand-cyan border-brand-cyan/20 hover:bg-brand-cyan/20">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-3">
                    <Button size="sm" variant="outline" className="flex-1 border-brand-cyan/50 text-brand-cyan hover:bg-brand-cyan/10">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      {t('liveDemo')}
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 border-brand-green/50 text-brand-green hover:bg-brand-green/10">
                      <Github className="mr-2 h-4 w-4" />
                      {t('viewCode')}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}