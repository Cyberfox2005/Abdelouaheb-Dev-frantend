import { Briefcase, Calendar } from "lucide-react";
import { useLanguage } from "./LanguageProvider";

const experiences = [
  {
    title: "Senior Full Stack Developer",
    company: "Tech Solutions Inc.",
    period: "2022 - Present",
    description: "Leading development of enterprise web applications, mentoring junior developers, and architecting scalable solutions.",
    achievements: [
      "Reduced application load time by 60% through optimization",
      "Led migration to microservices architecture",
      "Implemented CI/CD pipeline reducing deployment time by 80%"
    ]
  },
  {
    title: "Full Stack Developer",
    company: "Digital Innovations",
    period: "2020 - 2022",
    description: "Developed and maintained multiple client projects using React, Node.js, and AWS infrastructure.",
    achievements: [
      "Built 15+ production applications",
      "Improved code quality with comprehensive testing",
      "Collaborated with design team on UI/UX improvements"
    ]
  },
  {
    title: "Frontend Developer",
    company: "StartUp Ventures",
    period: "2019 - 2020",
    description: "Created responsive web applications and contributed to the company's design system.",
    achievements: [
      "Developed reusable component library",
      "Implemented responsive designs for mobile-first approach",
      "Participated in agile development process"
    ]
  }
];

export function Experience() {
  const { t } = useLanguage();
  
  return (
    <section id="experience" className="py-24 bg-gradient-to-b from-gray-50 to-white dark:from-brand-darker dark:to-brand-dark">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="mb-4 bg-gradient-to-r from-brand-cyan to-brand-purple bg-clip-text text-transparent">{t('experienceTitle')}</h2>
            <div className="w-20 h-1 bg-gradient-to-r from-brand-cyan via-brand-green to-brand-purple mx-auto mb-6"></div>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              {t('experienceDescription')}
            </p>
          </div>
          
          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all hover:-translate-y-1 border-l-4 border-brand-cyan">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                  <div>
                    <h3 className="mb-2 bg-gradient-to-r from-brand-cyan to-brand-green bg-clip-text text-transparent">{exp.title}</h3>
                    <div className="flex items-center gap-2 text-brand-cyan mb-2">
                      <Briefcase className="h-4 w-4" />
                      <span>{exp.company}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400 bg-brand-cyan/5 px-3 py-1 rounded-full border border-brand-cyan/20">
                    <Calendar className="h-4 w-4 text-brand-cyan" />
                    <span>{exp.period}</span>
                  </div>
                </div>
                
                <p className="text-gray-600 dark:text-gray-400 mb-4">{exp.description}</p>
                
                <div>
                  <div className="text-gray-700 mb-2">Key Achievements:</div>
                  <ul className="list-disc list-inside space-y-1 text-gray-600">
                    {exp.achievements.map((achievement, achIndex) => (
                      <li key={achIndex}>{achievement}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}