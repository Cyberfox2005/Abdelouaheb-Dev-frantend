import { ImageWithFallback } from "./figma/ImageWithFallback";
import profileImageDark from "figma:asset/9924fd72bc599674567ae61e63466315b12bb425.png";
import profileImageLight from "figma:asset/db191a8f1dc496e096a90c96c3790591f1a9bf77.png";
import { useLanguage } from "./LanguageProvider";
import { useTheme } from "./ThemeProvider";

export function About() {
  const { t } = useLanguage();
  const { theme } = useTheme();
  
  return (
    <section id="about" className="py-24 bg-gradient-to-b from-white to-gray-50 dark:from-brand-dark dark:to-brand-darker relative overflow-hidden">
      {/* Subtle animated background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 right-10 w-64 h-64 bg-brand-cyan/5 dark:bg-brand-cyan/10 rounded-full blur-3xl animate-pulse-glow" />
        <div className="absolute bottom-10 left-10 w-72 h-72 bg-brand-purple/5 dark:bg-brand-purple/10 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '2s' }} />
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-brand-cyan/40"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${8 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="mb-4 bg-gradient-to-r from-brand-cyan to-brand-purple bg-clip-text text-transparent">{t('aboutTitle')}</h2>
            <div className="w-20 h-1 bg-gradient-to-r from-brand-cyan via-brand-green to-brand-purple mx-auto"></div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="flex justify-center">
              <img
                src={theme === 'light' ? profileImageLight : profileImageDark}
                alt={t('name')}
                className="rounded-lg shadow-2xl w-full h-auto max-w-md object-cover"
              />
            </div>
            
            <div>
              <h3 className="mb-6 text-gray-900 dark:text-white">{t('aboutHeading')}</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                {t('aboutParagraph1')}
              </p>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                {t('aboutParagraph2')}
              </p>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                {t('aboutParagraph3')}
              </p>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="p-4 bg-gradient-to-br from-brand-cyan/10 to-brand-cyan/5 dark:from-brand-cyan/20 dark:to-brand-cyan/10 rounded-lg border border-brand-cyan/20 dark:border-brand-cyan/30">
                  <div className="bg-gradient-to-r from-brand-cyan to-brand-green bg-clip-text text-transparent mb-2">8+</div>
                  <div className="text-gray-600 dark:text-gray-300">{t('projectsCompleted')}</div>
                </div>
                <div className="p-4 bg-gradient-to-br from-brand-green/10 to-brand-green/5 dark:from-brand-green/20 dark:to-brand-green/10 rounded-lg border border-brand-green/20 dark:border-brand-green/30">
                  <div className="bg-gradient-to-r from-brand-green to-brand-cyan bg-clip-text text-transparent mb-2">9+</div>
                  <div className="text-gray-600 dark:text-gray-300">{t('techStacks')}</div>
                </div>
                <div className="p-4 bg-gradient-to-br from-brand-purple/10 to-brand-purple/5 dark:from-brand-purple/20 dark:to-brand-purple/10 rounded-lg border border-brand-purple/20 dark:border-brand-purple/30">
                  <div className="bg-gradient-to-r from-brand-purple to-brand-cyan bg-clip-text text-transparent mb-2">{t('fullStack')}</div>
                  <div className="text-gray-600 dark:text-gray-300">{t('development')}</div>
                </div>
                <div className="p-4 bg-gradient-to-br from-brand-cyan/10 to-brand-purple/5 dark:from-brand-cyan/20 dark:to-brand-purple/10 rounded-lg border border-brand-cyan/20 dark:border-brand-purple/30">
                  <div className="bg-gradient-to-r from-brand-cyan to-brand-purple bg-clip-text text-transparent mb-2">{t('mobileApp')}</div>
                  <div className="text-gray-600 dark:text-gray-300">{t('appDeveloper')}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}