import { useLanguage } from "./LanguageProvider";

const skillPaths = [
  {
    name: "Frontend Development",
    color: "from-brand-cyan to-brand-green",
    skills: [
      {
        name: "HTML",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg",
        color: "from-[#E34F26] to-[#c43e1f]"
      },
      {
        name: "CSS",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg",
        color: "from-[#1572B6] to-[#0e5a8f]"
      },
      {
        name: "JavaScript",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg",
        color: "from-[#F7DF1E] to-[#d4bc00]"
      },
      {
        name: "React",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg",
        color: "from-[#61DAFB] to-[#3db5d1]"
      },
      {
        name: "Tailwind CSS",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/tailwindcss/tailwindcss-original.svg",
        color: "from-[#06B6D4] to-[#0891a8]"
      },
      {
        name: "Bootstrap",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg",
        color: "from-[#7952B3] to-[#5c3d8a]"
      }
    ]
  },
  {
    name: "Backend PHP",
    color: "from-[#777BB4] to-[#FF2D20]",
    skills: [
      {
        name: "PHP",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg",
        color: "from-[#777BB4] to-[#555799]"
      },
      {
        name: "SQL",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg",
        color: "from-[#4479A1] to-[#345d7a]"
      },
      {
        name: "Laravel",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/laravel/laravel-original.svg",
        color: "from-[#FF2D20] to-[#cc241a]"
      }
    ]
  },
  {
    name: "Backend Python",
    color: "from-[#3776AB] to-[#092E20]",
    skills: [
      {
        name: "Python",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg",
        color: "from-[#3776AB] to-[#285d85]"
      },
      {
        name: "SQL",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg",
        color: "from-[#4479A1] to-[#345d7a]"
      },
      {
        name: "Flask",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/flask/flask-original.svg",
        color: "from-[#000000] to-[#1a1a1a]"
      },
      {
        name: "Django",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/django/django-plain.svg",
        color: "from-[#092E20] to-[#051f15]"
      }
    ]
  },
  {
    name: "Backend Node.js",
    color: "from-[#F7DF1E] to-[#339933]",
    skills: [
      {
        name: "JavaScript",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg",
        color: "from-[#F7DF1E] to-[#d4bc00]"
      },
      {
        name: "Node.js",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg",
        color: "from-[#339933] to-[#267326]"
      },
      {
        name: "SQL",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg",
        color: "from-[#4479A1] to-[#345d7a]"
      }
    ]
  },
  {
    name: "Mobile - React Native",
    color: "from-brand-cyan to-brand-purple",
    skills: [
      {
        name: "JavaScript",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg",
        color: "from-[#F7DF1E] to-[#d4bc00]"
      },
      {
        name: "React Native",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg",
        color: "from-brand-cyan to-brand-green"
      }
    ]
  },
  {
    name: "Mobile - Flutter",
    color: "from-[#0175C2] to-[#02569B]",
    skills: [
      {
        name: "Dart",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/dart/dart-original.svg",
        color: "from-[#0175C2] to-[#015a94]"
      },
      {
        name: "Flutter",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/flutter/flutter-original.svg",
        color: "from-[#02569B] to-[#01406e]"
      }
    ]
  },
  {
    name: "Mobile - iOS",
    color: "from-[#F05138] to-brand-purple",
    skills: [
      {
        name: "Swift",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/swift/swift-original.svg",
        color: "from-[#F05138] to-[#c93e2b]"
      }
    ]
  },
  {
    name: "Mobile - Android",
    color: "from-[#3DDC84] to-[#7F52FF]",
    skills: [
      {
        name: "Kotlin",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/kotlin/kotlin-original.svg",
        color: "from-[#7F52FF] to-[#6233cc]"
      }
    ]
  },
  {
    name: "System Programming",
    color: "from-[#A8B9CC] to-[#00599C]",
    skills: [
      {
        name: "C",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/c/c-original.svg",
        color: "from-[#A8B9CC] to-[#7d8fa3]"
      },
      {
        name: "C++",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg",
        color: "from-[#00599C] to-[#004577]"
      }
    ]
  },
  {
    name: "Enterprise Development",
    color: "from-[#007396] to-brand-green",
    skills: [
      {
        name: "Java",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg",
        color: "from-[#007396] to-[#00587a]"
      },
      {
        name: "SQL",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg",
        color: "from-[#4479A1] to-[#345d7a]"
      },
      {
        name: "Java EE",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg",
        color: "from-[#007396] to-brand-green"
      },
      {
        name: "Spring Boot",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/spring/spring-original.svg",
        color: "from-[#6DB33F] to-[#519b2f]"
      }
    ]
  },
  {
    name: "Apps Development",
    color: "from-[#239120] to-[#178600]",
    skills: [
      {
        name: "C#",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg",
        color: "from-[#239120] to-[#178600]"
      },
      {
        name: "C++",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg",
        color: "from-[#00599C] to-[#004577]"
      },
      {
        name: "Java",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg",
        color: "from-[#007396] to-[#00587a]"
      },
      {
        name: "JavaFX",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg",
        color: "from-[#007396] to-brand-green"
      },
      {
        name: "XML",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/xml/xml-original.svg",
        color: "from-[#FF6600] to-[#cc5200]"
      }
    ]
  },
  {
    name: "Game Development",
    color: "from-[#FF0066] to-[#9933FF]",
    skills: [
      {
        name: "C#",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg",
        color: "from-[#239120] to-[#178600]"
      },
      {
        name: "C++",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg",
        color: "from-[#00599C] to-[#004577]"
      },
      {
        name: "Unity",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/unity/unity-original.svg",
        color: "from-[#000000] to-[#1a1a1a]"
      }
    ]
  },
  {
    name: "Databases",
    color: "from-[#4479A1] to-[#47A248]",
    skills: [
      {
        name: "MySQL",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg",
        color: "from-[#4479A1] to-[#345d7a]"
      },
      {
        name: "PostgreSQL",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg",
        color: "from-[#336791] to-[#264f6f]"
      },
      {
        name: "MongoDB",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg",
        color: "from-[#47A248] to-[#38813a]"
      },
      {
        name: "Oracle",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/oracle/oracle-original.svg",
        color: "from-[#F80000] to-[#c40000]"
      }
    ]
  },
  {
    name: "Server Architecture",
    color: "from-[#2496ED] to-[#FF9900]",
    skills: [
      {
        name: "Docker",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/docker/docker-original.svg",
        color: "from-[#2496ED] to-[#1a75bb]"
      },
      {
        name: "Kubernetes",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/kubernetes/kubernetes-plain.svg",
        color: "from-[#326CE5] to-[#2554b5]"
      },
      {
        name: "AWS",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/amazonwebservices/amazonwebservices-original-wordmark.svg",
        color: "from-[#FF9900] to-[#cc7a00]"
      },
      {
        name: "Linux",
        logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linux/linux-original.svg",
        color: "from-[#FCC624] to-[#ca9e1d]"
      }
    ]
  }
];

export function Skills() {
  const { t } = useLanguage();
  
  const pathNames: { [key: string]: string } = {
    "Frontend Development": t('frontendDev'),
    "Backend PHP": t('backendPHP'),
    "Backend Python": t('backendPython'),
    "Backend Node.js": t('backendNode'),
    "Mobile - React Native": t('mobileReactNative'),
    "Mobile - Flutter": t('mobileFlutter'),
    "Mobile - iOS": t('mobileIOS'),
    "Mobile - Android": t('mobileAndroid'),
    "System Programming": t('systemProgramming'),
    "Enterprise Development": t('enterpriseDev'),
    "Apps Development": t('appsDev'),
    "Game Development": t('gameDev'),
    "Databases": t('databases'),
    "Server Architecture": t('serverArchitecture')
  };
  
  return (
    <section id="skills" className="py-24 bg-gradient-to-b from-gray-50 to-white dark:from-brand-darker dark:to-brand-dark relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-20 w-56 h-56 bg-brand-green/5 dark:bg-brand-green/10 rounded-full blur-3xl animate-pulse-glow" />
        <div className="absolute bottom-20 right-20 w-64 h-64 bg-brand-cyan/5 dark:bg-brand-cyan/10 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '1s' }} />
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-brand-purple/30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${10 + Math.random() * 5}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="mb-4 bg-gradient-to-r from-brand-cyan to-brand-purple bg-clip-text text-transparent">{t('skillsTitle')}</h2>
            <div className="w-20 h-1 bg-gradient-to-r from-brand-cyan via-brand-green to-brand-purple mx-auto mb-6"></div>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              {t('skillsDescription')}
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skillPaths.map((path, pathIndex) => (
              <div
                key={pathIndex}
                className="relative bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-xl border-2 border-gray-200 dark:border-gray-700 hover:border-brand-cyan/50 dark:hover:border-brand-cyan/50 transition-all duration-300"
              >
                {/* Path header */}
                <div className="mb-6">
                  <h3 className={`text-center bg-gradient-to-r ${path.color} bg-clip-text text-transparent font-bold`}>
                    {pathNames[path.name] || path.name}
                  </h3>
                  <div className={`w-full h-1 bg-gradient-to-r ${path.color} mt-2 rounded-full`}></div>
                </div>
                
                {/* Skills flow */}
                <div className="flex flex-col gap-4">
                  {path.skills.map((skill, skillIndex) => (
                    <div key={skillIndex}>
                      <div
                        className="group relative"
                        style={{ perspective: "1000px" }}
                      >
                        <div 
                          className="relative bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 p-4 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300 hover:shadow-2xl hover:border-brand-cyan/50 dark:hover:border-brand-cyan/50 hover:-translate-y-1"
                          style={{
                            transformStyle: "preserve-3d",
                            transform: "translateZ(0)",
                          }}
                        >
                          {/* 3D effect layer */}
                          <div 
                            className="absolute inset-0 bg-gradient-to-br from-brand-cyan/5 to-brand-purple/5 dark:from-brand-cyan/10 dark:to-brand-purple/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                            style={{ transform: "translateZ(-10px)" }}
                          ></div>
                          
                          {/* Content */}
                          <div 
                            className="relative z-10 flex items-center gap-4 transition-transform duration-300 group-hover:scale-105"
                            style={{ transform: "translateZ(20px)" }}
                          >
                            <div 
                              className={`w-16 h-16 flex items-center justify-center rounded-xl bg-gradient-to-br ${skill.color} p-3 shadow-xl transition-all duration-300 group-hover:shadow-2xl group-hover:rotate-6`}
                              style={{ transformStyle: "preserve-3d" }}
                            >
                              {/* White background for better logo visibility */}
                              <div className="absolute inset-1 bg-white dark:bg-gray-900 rounded-lg"></div>
                              <img 
                                src={skill.logo} 
                                alt={skill.name}
                                className="relative z-10 w-full h-full object-contain filter drop-shadow-lg"
                              />
                            </div>
                            <h4 className="text-base font-semibold text-gray-800 dark:text-gray-200 transition-colors duration-300 group-hover:text-brand-cyan dark:group-hover:text-brand-cyan">
                              {skill.name}
                            </h4>
                          </div>
                          
                          {/* Shine effect */}
                          <div 
                            className="absolute inset-0 rounded-xl bg-gradient-to-tr from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                            style={{ transform: "translateZ(30px)" }}
                          ></div>
                        </div>
                      </div>
                      
                      {/* Arrow connector between skills */}
                      {skillIndex < path.skills.length - 1 && (
                        <div className="flex justify-center py-2">
                          <svg className="w-6 h-6 text-brand-cyan dark:text-brand-cyan" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                          </svg>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}