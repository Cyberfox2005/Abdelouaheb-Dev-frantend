import { Github, Linkedin, Mail, ArrowDown } from "lucide-react";
import { Button } from "./ui/button";
import logoImage from "figma:asset/d3fb022417f356c7ca48d8ab4a07b126226cc9b4.png";
import { useLanguage } from "./LanguageProvider";
import { AnimatedBackground } from "./AnimatedBackground";

export function Hero() {
  const { t } = useLanguage();
  
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0A0F1E] via-[#050812] to-[#0A0F1E] dark:from-[#0A0F1E] dark:via-[#050812] dark:to-[#0A0F1E] light:from-blue-50 light:via-purple-50 light:to-cyan-50 text-foreground relative overflow-hidden">
      {/* Animated Background */}
      <AnimatedBackground />
      
      {/* Animated circuit pattern background */}
      <div className="absolute inset-0 opacity-10 dark:opacity-10 light:opacity-5">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMtMy4zMTQgMC02IDIuNjg2LTYgNnMyLjY4NiA2IDYgNiA2LTIuNjg2IDYtNi0yLjY4Ni02LTYtNnoiIHN0cm9rZT0iIzAwRDlGRiIvPjwvZz48L3N2Zz4=')] animate-pulse"></div>
      </div>
      
      {/* Gradient orbs */}
      <div className="absolute top-1/4 -left-48 w-96 h-96 bg-brand-cyan/20 dark:bg-brand-cyan/20 light:bg-brand-cyan/30 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 -right-48 w-96 h-96 bg-brand-purple/20 dark:bg-brand-purple/20 light:bg-brand-purple/30 rounded-full blur-3xl"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-brand-green/10 dark:bg-brand-green/10 light:bg-brand-green/20 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Logo */}
          <div className="mb-8 flex justify-center">
            <img 
              src={logoImage} 
              alt="ABD EL OUAHEB DEV Logo" 
              className="w-48 h-auto animate-pulse"
            />
          </div>
          
          <div className="mb-6">
            <span className="inline-block px-4 py-2 bg-brand-cyan/10 text-brand-cyan rounded-full border border-brand-cyan/30 backdrop-blur-sm">
              {t('welcome')}
            </span>
          </div>
          
          <h1 className="mb-6 bg-gradient-to-r from-brand-cyan via-brand-green to-brand-purple bg-clip-text text-transparent">
            {t('name')}
          </h1>
          
          <h2 className="mb-8 text-gray-300 dark:text-gray-300 light:text-gray-700">
            {t('title')}
          </h2>
          
          <p className="text-xl text-gray-400 dark:text-gray-400 light:text-gray-600 mb-12 max-w-2xl mx-auto">
            {t('heroDescription')}
          </p>
          
          <div className="flex gap-4 justify-center mb-12">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-brand-cyan to-brand-green hover:from-brand-cyan/90 hover:to-brand-green/90 text-white border-0"
              onClick={() => scrollToSection('contact')}
            >
              <Mail className="mr-2 h-4 w-4" />
              {t('getInTouch')}
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-brand-cyan/50 text-brand-cyan hover:bg-brand-cyan/10 hover:border-brand-cyan"
              onClick={() => scrollToSection('projects')}
            >
              {t('viewProjects')}
            </Button>
          </div>
          
          <div className="flex gap-6 justify-center">
            <a href="https://github.com/Cyberfox2005" target="_blank" rel="noopener noreferrer" className="text-gray-400 dark:text-gray-400 light:text-gray-600 hover:text-brand-cyan transition-all hover:scale-110">
              <Github className="h-6 w-6" />
            </a>
            <a href="https://www.linkedin.com/in/abdelouhab-benachi-4628632b0/" target="_blank" rel="noopener noreferrer" className="text-gray-400 dark:text-gray-400 light:text-gray-600 hover:text-brand-cyan transition-all hover:scale-110">
              <Linkedin className="h-6 w-6" />
            </a>
            <a href="mailto:ben689533@gmail.com" className="text-gray-400 dark:text-gray-400 light:text-gray-600 hover:text-brand-cyan transition-all hover:scale-110">
              <Mail className="h-6 w-6" />
            </a>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ArrowDown className="h-6 w-6 text-brand-cyan" />
      </div>
    </section>
  );
}